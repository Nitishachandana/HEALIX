import json
import urllib.request
import urllib.error
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.conf import settings
from .models import ChatMessage

SYSTEM_PROMPT = """You are Healix AI, an intelligent healthcare assistant. When a user describes symptoms, respond with a JSON object (no markdown, no backticks) in exactly this format:
{
  "intro": "A warm 1-2 sentence acknowledgment of the symptoms",
  "disease": "Potential condition name",
  "risk": "high|medium|low",
  "riskPct": 0-100,
  "riskNote": "brief risk explanation",
  "precautions": ["precaution 1","precaution 2","precaution 3","precaution 4"],
  "specialty": "Recommended specialist type",
  "followUp": "A short follow-up question or advice sentence"
}
Always be medically responsible, suggest seeing a real doctor, and keep tone warm and professional. For high risk symptoms like chest pain, always recommend emergency care."""


@login_required
def chat_history(request):
    msgs = ChatMessage.objects.filter(user=request.user).order_by('created_at')[:50]
    data = [{'role': m.role, 'content': m.content} for m in msgs]
    return JsonResponse({'messages': data})


@csrf_exempt
@login_required
@require_POST
def send_message(request):
    data = json.loads(request.body)
    user_text = data.get('message', '').strip()
    if not user_text:
        return JsonResponse({'ok': False, 'error': 'Empty message'}, status=400)

    # Save user message
    ChatMessage.objects.create(user=request.user, role='user', content=user_text)

    api_key = settings.ANTHROPIC_API_KEY
    if not api_key:
        # Return fallback so UI can use its built-in DISEASE_DB
        return JsonResponse({'ok': True, 'fallback': True})

    # Build message history for context (last 10)
    history = list(
        ChatMessage.objects.filter(user=request.user)
        .order_by('-created_at')[:10]
        .values('role', 'content')
    )
    history.reverse()

    payload = json.dumps({
        'model': 'claude-sonnet-4-20250514',
        'max_tokens': 1000,
        'system': SYSTEM_PROMPT,
        'messages': [{'role': m['role'], 'content': m['content']} for m in history],
    }).encode('utf-8')

    req = urllib.request.Request(
        'https://api.anthropic.com/v1/messages',
        data=payload,
        headers={
            'Content-Type': 'application/json',
            'x-api-key': api_key,
            'anthropic-version': '2023-06-01',
        },
        method='POST',
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode('utf-8'))
        raw = ''.join(b.get('text', '') for b in result.get('content', []))
        # Save assistant reply
        ChatMessage.objects.create(user=request.user, role='assistant', content=raw)
        try:
            parsed = json.loads(raw.replace('```json', '').replace('```', '').strip())
            return JsonResponse({'ok': True, 'analysis': parsed})
        except json.JSONDecodeError:
            return JsonResponse({'ok': True, 'raw': raw})
    except urllib.error.URLError as e:
        return JsonResponse({'ok': True, 'fallback': True})


@csrf_exempt
@login_required
@require_POST
def clear_history(request):
    ChatMessage.objects.filter(user=request.user).delete()
    return JsonResponse({'ok': True})
