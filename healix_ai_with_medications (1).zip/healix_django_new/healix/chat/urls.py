from django.urls import path
from . import views

urlpatterns = [
    path('history/', views.chat_history, name='chat_history'),
    path('send/', views.send_message, name='chat_send'),
    path('clear/', views.clear_history, name='chat_clear'),
]
