from django.contrib import admin
from .models import Appointment

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('patient', 'doctor_name', 'specialization', 'date', 'time', 'status')
    list_filter = ('status', 'apt_type')
    search_fields = ('patient__username', 'doctor_name')
