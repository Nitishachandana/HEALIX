import json
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from .models import Appointment


@login_required
def list_appointments(request):
    status_filter = request.GET.get('status', 'all')
    qs = Appointment.objects.filter(patient=request.user)
    if status_filter != 'all':
        qs = qs.filter(status=status_filter)
    data = [
        {
            'id': a.id,
            'doctor': a.doctor_name,
            'spec': a.specialization,
            'date': str(a.date),
            'time': a.time,
            'type': a.apt_type,
            'status': a.status,
            'notes': a.notes,
        }
        for a in qs
    ]
    return JsonResponse({'appointments': data})


@csrf_exempt
@login_required
@require_POST
def book_appointment(request):
    data = json.loads(request.body)
    apt = Appointment.objects.create(
        patient=request.user,
        doctor_name=data.get('doctor', ''),
        specialization=data.get('spec', ''),
        date=data.get('date'),
        time=data.get('time', ''),
        apt_type=data.get('type', 'Video'),
        notes=data.get('notes', ''),
        status='upcoming',
    )
    return JsonResponse({'ok': True, 'id': apt.id})


@csrf_exempt
@login_required
@require_POST
def cancel_appointment(request, apt_id):
    try:
        apt = Appointment.objects.get(id=apt_id, patient=request.user)
        apt.status = 'cancelled'
        apt.save()
        return JsonResponse({'ok': True})
    except Appointment.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
