from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.list_appointments, name='appointments_list'),
    path('book/', views.book_appointment, name='book_appointment'),
    path('cancel/<int:apt_id>/', views.cancel_appointment, name='cancel_appointment'),
]
