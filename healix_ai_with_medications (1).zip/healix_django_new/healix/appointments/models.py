from django.db import models
from django.conf import settings


class Appointment(models.Model):
    STATUS_CHOICES = [
        ('upcoming', 'Upcoming'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    TYPE_CHOICES = [
        ('Video', 'Video Consultation'),
        ('In-Person', 'In-Person Visit'),
        ('Follow-up', 'Follow-up'),
    ]

    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='patient_appointments'
    )
    doctor_name = models.CharField(max_length=120)
    specialization = models.CharField(max_length=120, blank=True)
    date = models.DateField()
    time = models.CharField(max_length=20)
    apt_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='Video')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='upcoming')
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f"{self.patient} → {self.doctor_name} on {self.date}"
