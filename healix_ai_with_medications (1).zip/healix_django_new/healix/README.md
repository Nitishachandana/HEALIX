# Healix AI — Django Healthcare Platform

A full-stack Django implementation of the Healix AI healthcare platform, converted from a single-file HTML prototype into a properly structured Django project with separate frontend and backend.

---

## Project Structure

```
healix/
├── manage.py
├── requirements.txt
├── db.sqlite3              ← created after migrations
│
├── healix_project/         ← Django project config
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
│
├── core/                   ← Main SPA shell & static files
│   ├── views.py            ← index + session_info views
│   ├── urls.py
│   ├── templates/
│   │   └── core/
│   │       └── index.html  ← Django template (the full UI)
│   └── static/
│       ├── css/
│       │   └── styles.css  ← All extracted CSS
│       └── js/
│           └── app.js      ← All extracted JS (Django API calls)
│
├── users/                  ← Auth (CustomUser with role field)
│   ├── models.py
│   ├── views.py            ← /auth/login/, /auth/signup/, /auth/logout/
│   ├── urls.py
│   └── admin.py
│
├── appointments/           ← Appointment CRUD
│   ├── models.py
│   ├── views.py            ← /appointments/list|book|cancel/
│   ├── urls.py
│   └── admin.py
│
├── doctors/                ← Doctor listings & patient requests
│   ├── models.py
│   ├── views.py            ← /doctors/list/, /doctors/requests/
│   ├── urls.py
│   ├── admin.py
│   └── fixtures/
│       └── initial_data.json  ← 6 doctors + sample requests
│
└── chat/                   ← AI chat history (proxies Anthropic API)
    ├── models.py
    ├── views.py            ← /chat/send/, /chat/history/, /chat/clear/
    ├── urls.py
    └── admin.py
```

---

## Quick Start

### 1. Install dependencies
```bash
cd healix
pip install -r requirements.txt
```

### 2. Run migrations
```bash
python manage.py migrate
```

### 3. Load seed data (doctors & sample patient requests)
```bash
python manage.py loaddata doctors/fixtures/initial_data.json
```

### 4. (Optional) Set your Anthropic API key
The AI chat works without a key using the built-in local DISEASE_DB fallback.
To enable real Claude AI responses, set the environment variable:
```bash
# Windows
set ANTHROPIC_API_KEY=sk-ant-...

# Mac/Linux
export ANTHROPIC_API_KEY=sk-ant-...
```
Or edit `healix_project/settings.py` and replace the empty string in:
```python
ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY', 'sk-ant-YOUR-KEY-HERE')
```

### 5. Create a superuser (optional, for Django admin)
```bash
python manage.py createsuperuser
```

### 6. Run the development server
```bash
python manage.py runserver
```

Open http://127.0.0.1:8000 in your browser.

---

## Demo Login (No signup needed)

On the login page, click any of the 3 demo buttons:
- **Patient** — Access the patient dashboard with AI chat, appointments, doctors
- **Doctor** — Access the doctor dashboard with patient requests, schedule
- **Admin** — Same as patient (admin panel at /admin/)

---

## API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| POST | /auth/login/ | Login with email+password or demo role |
| POST | /auth/signup/ | Register new account |
| POST | /auth/logout/ | Logout |
| GET  | /session/ | Check current session |
| GET  | /appointments/list/?status=all | List appointments |
| POST | /appointments/book/ | Book new appointment |
| POST | /appointments/cancel/<id>/ | Cancel appointment |
| GET  | /doctors/list/?q= | List/search doctors |
| GET  | /doctors/requests/ | List patient requests (doctor) |
| POST | /doctors/requests/<id>/respond/ | Accept/decline request |
| POST | /chat/send/ | Send message to AI |
| GET  | /chat/history/ | Get chat history |
| POST | /chat/clear/ | Clear chat history |

---

## How the AI Chat Works

1. User types a symptom → JS calls `POST /chat/send/`
2. Django saves the message, then calls the Anthropic API server-side (keeps your key secure)
3. If no API key is set → Django returns `{"fallback": true}` → JS uses the built-in DISEASE_DB
4. The response is rendered as a diagnosis card with risk level, precautions, and specialist recommendation

---

## Django Admin

Visit http://127.0.0.1:8000/admin/ to manage:
- Users (with role: patient/doctor/admin)
- Appointments
- Doctors & Patient Requests
- Chat message history
