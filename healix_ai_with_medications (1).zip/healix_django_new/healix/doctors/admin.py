from django.contrib import admin
from .models import Doctor, PatientRequest

@admin.register(Doctor)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ('name', 'specialization', 'rating', 'available')
    list_filter = ('available', 'specialization')

@admin.register(PatientRequest)
class PatientRequestAdmin(admin.ModelAdmin):
    list_display = ('patient_name', 'age', 'risk', 'accepted', 'created_at')
    list_filter = ('risk', 'accepted')
