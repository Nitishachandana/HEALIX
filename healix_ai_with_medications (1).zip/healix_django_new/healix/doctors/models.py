from django.db import models


class Doctor(models.Model):
    name = models.CharField(max_length=120)
    specialization = models.CharField(max_length=120)
    experience = models.CharField(max_length=30)   # e.g. "14 yrs"
    total_patients = models.CharField(max_length=20)  # e.g. "1.2K"
    rating = models.DecimalField(max_digits=3, decimal_places=1, default=4.5)
    reviews = models.IntegerField(default=0)
    available = models.BooleanField(default=True)
    bio = models.TextField(blank=True)
    emoji = models.CharField(max_length=10, default='👨‍⚕️')
    color = models.CharField(max_length=20, default='avatar-blue')

    def __str__(self):
        return f"{self.name} — {self.specialization}"


class PatientRequest(models.Model):
    RISK_CHOICES = [('high', 'High'), ('medium', 'Medium'), ('low', 'Low')]
    patient_name = models.CharField(max_length=120)
    age = models.IntegerField()
    symptom = models.TextField()
    risk = models.CharField(max_length=10, choices=RISK_CHOICES, default='low')
    accepted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.patient_name} ({self.risk} risk)"
