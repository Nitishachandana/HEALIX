from django.urls import path
from . import views

urlpatterns = [
    path('list/', views.list_doctors, name='doctors_list'),
    path('requests/', views.list_patient_requests, name='patient_requests'),
    path('requests/<int:req_id>/respond/', views.respond_request, name='respond_request'),
]
