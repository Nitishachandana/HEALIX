import json
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from .models import Doctor, PatientRequest


@login_required
def list_doctors(request):
    search = request.GET.get('q', '').strip().lower()
    qs = Doctor.objects.all()
    if search:
        qs = qs.filter(name__icontains=search) | Doctor.objects.filter(specialization__icontains=search)
    data = [
        {
            'id': d.id,
            'name': d.name,
            'spec': d.specialization,
            'exp': d.experience,
            'patients': d.total_patients,
            'rating': float(d.rating),
            'reviews': d.reviews,
            'available': d.available,
            'bio': d.bio,
            'emoji': d.emoji,
            'color': d.color,
        }
        for d in qs
    ]
    return JsonResponse({'doctors': data})


@login_required
def list_patient_requests(request):
    qs = PatientRequest.objects.all()
    data = [
        {
            'id': r.id,
            'name': r.patient_name,
            'age': r.age,
            'symptom': r.symptom,
            'risk': r.risk,
            'accepted': r.accepted,
            'time': r.created_at.strftime('%b %d, %H:%M'),
        }
        for r in qs
    ]
    return JsonResponse({'requests': data})


@csrf_exempt
@login_required
@require_POST
def respond_request(request, req_id):
    data = json.loads(request.body)
    action = data.get('action')  # 'accept' or 'decline'
    try:
        req = PatientRequest.objects.get(id=req_id)
        if action == 'accept':
            req.accepted = True
            req.save()
            return JsonResponse({'ok': True, 'accepted': True})
        elif action == 'decline':
            req.delete()
            return JsonResponse({'ok': True, 'declined': True})
        return JsonResponse({'ok': False, 'error': 'Unknown action'}, status=400)
    except PatientRequest.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
