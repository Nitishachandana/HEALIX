from django.shortcuts import render
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required


def index(request):
    """Serve the main SPA. Pass auth state to template."""
    ctx = {
        'is_authenticated': request.user.is_authenticated,
        'user_role': getattr(request.user, 'role', '') if request.user.is_authenticated else '',
        'user_name': request.user.get_full_name() if request.user.is_authenticated else '',
    }
    return render(request, 'core/index.html', ctx)


def session_info(request):
    if request.user.is_authenticated:
        return JsonResponse({
            'authenticated': True,
            'role': request.user.role,
            'name': request.user.display_name,
        })
    return JsonResponse({'authenticated': False})


def dashboard(request):
    """Redirect helper — just serves the SPA again."""
    return render(request, 'core/index.html', {
        'is_authenticated': request.user.is_authenticated,
        'user_role': getattr(request.user, 'role', '') if request.user.is_authenticated else '',
        'user_name': request.user.get_full_name() if request.user.is_authenticated else '',
    })
