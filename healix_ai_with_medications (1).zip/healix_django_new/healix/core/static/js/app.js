/* ========================
   HEALIX AI — app.js
   Django-connected frontend
   ======================== */

const CSRF = () => document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';

const API = {
  post: (url, data) => fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRFToken': CSRF() },
    body: JSON.stringify(data)
  }).then(r => r.json()),
  get: (url) => fetch(url).then(r => r.json()),
};

/* ========================
   STATE
   ======================== */
const state = {
  currentUser: null,
  currentRole: null,
  appointments: [],
  patientRequests: [],
  doctors: [],
  videoStream: null,
  callTimer: null,
  callSeconds: 0,
  micOn: true,
  camOn: true,
  recognition: null,
  isListening: false,
  selectedDoctorForModal: null,
  prevPage: null,
};

/* ========================
   AUTH
   ======================== */
function switchAuthTab(tab) {
  document.getElementById('tab-login').classList.toggle('active', tab === 'login');
  document.getElementById('tab-signup').classList.toggle('active', tab === 'signup');
  document.getElementById('login-form').classList.toggle('hidden', tab !== 'login');
  document.getElementById('signup-form').classList.toggle('hidden', tab !== 'signup');
}

async function handleLogin() {
  const email = document.getElementById('login-email').value.trim();
  const pw = document.getElementById('login-password').value.trim();
  if (!email || !pw) { showToast('Please fill in all fields', 'error'); return; }
  const res = await API.post('/auth/login/', { email, password: pw });
  if (res.ok) loginSuccess(res.name, res.role);
  else showToast(res.error || 'Login failed', 'error');
}

async function handleSignup() {
  const name = document.getElementById('signup-name').value.trim();
  const email = document.getElementById('signup-email').value.trim();
  const pw = document.getElementById('signup-password').value.trim();
  const role = document.getElementById('signup-role').value;
  if (!name || !email || !pw) { showToast('Please fill in all fields', 'error'); return; }
  const res = await API.post('/auth/signup/', { name, email, password: pw, role });
  if (res.ok) loginSuccess(res.name, res.role);
  else showToast(res.error || 'Signup failed', 'error');
}

async function demoLogin(role) {
  const res = await API.post('/auth/login/', { demo: true, role });
  if (res.ok) loginSuccess(res.name, res.role);
  else showToast('Demo login failed', 'error');
}

function loginSuccess(name, role) {
  state.currentUser = name;
  state.currentRole = role;
  showToast(`Welcome back, ${name}! 👋`, 'success');
  document.getElementById('login-page').classList.add('hidden');
  if (role === 'doctor') {
    document.getElementById('doctor-dashboard').classList.remove('hidden');
    document.getElementById('doctor-name-display').textContent = name;
    document.getElementById('doctor-avatar').textContent = name.charAt(0);
    greetDoctor();
    initDoctorDashboard();
  } else {
    document.getElementById('patient-dashboard').classList.remove('hidden');
    document.getElementById('patient-name-display').textContent = name;
    document.getElementById('patient-avatar').textContent = name.charAt(0);
    initPatientDashboard();
  }
}

async function logout() {
  await API.post('/auth/logout/', {});
  state.currentUser = null;
  state.currentRole = null;
  document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
  document.getElementById('login-page').classList.remove('hidden');
  showToast('Logged out successfully', 'info');
}

/* ========================
   PATIENT DASHBOARD
   ======================== */
async function initPatientDashboard() {
  await loadAppointments();
  await loadDoctors();
}

function showPanel(name) {
  document.querySelectorAll('#patient-dashboard .main-content > div[id^="panel-"]').forEach(p => p.classList.add('hidden'));
  document.getElementById('panel-' + name).classList.remove('hidden');
  document.querySelectorAll('#patient-sidebar .nav-item').forEach(i => i.classList.remove('active'));
  document.querySelectorAll('#patient-sidebar .nav-item').forEach(item => {
    if (item.textContent.trim().toLowerCase().includes(name.replace('-', ' ').toLowerCase())) item.classList.add('active');
  });
}

/* ========================
   CHAT / AI
   ======================== */
function handleChatKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function sendQuick(text) {
  document.getElementById('chat-input').value = text;
  sendMessage();
}

async function sendMessage() {
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text) return;
  appendMessage('user', text);
  input.value = ''; input.style.height = 'auto';
  document.getElementById('chat-welcome')?.remove();
  showTyping();
  // Call Django backend which proxies to Claude API
  try {
    const res = await API.post('/chat/send/', { message: text });
    removeTyping();
    if (res.ok && res.analysis) renderAIResponse(res.analysis);
    else if (res.ok && res.raw) appendMessage('ai', res.raw);
    else fallbackAnalysis(text);
  } catch (e) {
    removeTyping();
    fallbackAnalysis(text);
  }
}

function appendMessage(role, content, isHTML = false) {
  const msgs = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = `message ${role}`;
  const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  const avatarLetter = role === 'user' ? (state.currentUser || 'U').charAt(0) : '🤖';
  const avatarClass = role === 'user' ? 'msg-user-avatar' : 'msg-ai-avatar';
  div.innerHTML = `
    <div class="message-avatar ${avatarClass}">${avatarLetter}</div>
    <div>
      <div class="message-bubble">${isHTML ? content : escapeHtml(content)}</div>
      <div class="message-time">${time}</div>
    </div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function showTyping() {
  const msgs = document.getElementById('chat-messages');
  const div = document.createElement('div');
  div.className = 'message ai'; div.id = 'typing-msg';
  div.innerHTML = `<div class="message-avatar msg-ai-avatar">🤖</div><div><div class="message-bubble"><div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div></div>`;
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function removeTyping() { document.getElementById('typing-msg')?.remove(); }

const DISEASE_DB = {
  'flu|influenza|fever.*cough|cough.*fever': { disease: 'Seasonal Influenza', risk: 'medium', riskPct: 48, precautions: ['Rest for 5–7 days to recover', 'Stay hydrated with warm fluids', 'Avoid contact with others', 'Take paracetamol for fever relief'], specialty: 'General Physician' },
  'chest.*pain|heart.*pain|shortness.*breath|breathing.*difficulty': { disease: 'Cardiac Concern (Possible Angina)', risk: 'high', riskPct: 85, precautions: ['Seek emergency care immediately', 'Avoid physical exertion', 'Take prescribed nitroglycerin if available', 'Do NOT drive yourself to hospital'], specialty: 'Cardiologist' },
  'headache.*fever|fever.*headache|migraine|severe.*head': { disease: 'Migraine / Tension Headache', risk: 'medium', riskPct: 42, precautions: ['Rest in a dark, quiet room', 'Apply cold compress to forehead', 'Stay hydrated', 'Avoid screen exposure'], specialty: 'Neurologist' },
  'cough.*throat|sore.*throat|throat.*pain': { disease: 'Upper Respiratory Infection', risk: 'low', riskPct: 28, precautions: ['Gargle with warm salt water', 'Stay hydrated', 'Avoid cold drinks', 'Honey + ginger tea helps soothe'], specialty: 'General Physician' },
  'joint.*pain|knee.*pain|arthritis|stiffness': { disease: 'Arthritis / Joint Inflammation', risk: 'medium', riskPct: 55, precautions: ['Apply warm compress to joints', 'Avoid high-impact activities', 'Take anti-inflammatory meds as prescribed', 'Physical therapy recommended'], specialty: 'Orthopedist' },
  'rash|itching|skin|eczema': { disease: 'Dermatitis / Allergic Reaction', risk: 'low', riskPct: 22, precautions: ['Avoid known allergens', 'Keep skin moisturized', 'Do not scratch affected areas', 'Use hypoallergenic products'], specialty: 'Dermatologist' },
  'dizzy|dizziness|nausea|vertigo': { disease: 'Vertigo / Vestibular Disorder', risk: 'medium', riskPct: 38, precautions: ['Avoid sudden movements', 'Sit down immediately when dizzy', 'Stay hydrated', 'Avoid caffeine and alcohol'], specialty: 'Neurologist' },
  'stomach.*pain|abdominal.*pain|gastric|indigestion|bloating': { disease: 'Gastrointestinal Issue', risk: 'low', riskPct: 30, precautions: ['Eat small, frequent meals', 'Avoid spicy and fatty foods', 'Stay hydrated', 'Try probiotic foods'], specialty: 'Gastroenterologist' },
};

function fallbackAnalysis(text) {
  const lower = text.toLowerCase();
  let match = null;
  for (const [pattern, data] of Object.entries(DISEASE_DB)) {
    if (new RegExp(pattern).test(lower)) { match = data; break; }
  }
  if (!match) match = { disease: 'General Health Concern', risk: 'low', riskPct: 20, precautions: ['Monitor symptoms closely', 'Stay hydrated and rest', 'Consult a general physician if symptoms persist', 'Keep a symptom diary'], specialty: 'General Physician' };
  renderAIResponse({
    intro: "I've analyzed your symptoms. Here's what I found:",
    disease: match.disease, risk: match.risk, riskPct: match.riskPct,
    riskNote: match.risk === 'high' ? 'Requires immediate medical attention' : match.risk === 'medium' ? 'Consult a doctor within 24–48 hours' : 'Monitor and rest; see a doctor if worsening',
    precautions: match.precautions, specialty: match.specialty,
    followUp: 'Would you like me to recommend available specialists and help you book an appointment?'
  });
}

function renderAIResponse(a) {
  const riskLabel = a.risk === 'high' ? 'High Risk' : a.risk === 'medium' ? 'Moderate Risk' : 'Low Risk';
  const riskBadge = `badge-${a.risk === 'high' ? 'high' : a.risk === 'medium' ? 'medium' : 'low'}`;
  const precs = (a.precautions || []).map(p => `<div class="precaution-item"><i class="fas fa-check-circle"></i><span>${p}</span></div>`).join('');
  const html = `
    <p style="margin-bottom:12px;color:var(--text-secondary);font-size:14px">${a.intro || ''}</p>
    <div class="diagnosis-card risk-${a.risk}">
      <div class="diagnosis-disease">${a.disease}<span class="badge ${riskBadge}">${riskLabel}</span></div>
      <div style="font-size:13px;color:var(--text-secondary);margin-top:4px">${a.riskNote || ''}</div>
      <div class="risk-bar"><div class="risk-fill" style="width:${a.riskPct || 30}%"></div></div>
      <div class="risk-percent">${a.riskPct || 30}% risk level</div>
      <div class="diagnosis-section">
        <div class="diagnosis-section-title">Precautions & Advice</div>${precs}
      </div>
      ${a.risk === 'high' ? `<div style="margin-top:12px;padding:10px 12px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.25);border-radius:8px;font-size:13px;color:#f87171"><i class="fas fa-exclamation-triangle"></i> <strong>Emergency Alert:</strong> Please seek immediate medical attention or call emergency services.</div>` : ''}
    </div>
    <div style="margin-top:10px;padding:12px;background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.15);border-radius:10px;font-size:13px;color:var(--text-secondary)">
      <i class="fas fa-user-md" style="color:var(--accent-blue)"></i> <strong>Recommended Specialist:</strong> ${a.specialty || 'General Physician'}
    </div>
    ${a.followUp ? `<p style="margin-top:10px;font-size:14px;color:var(--text-secondary)">${a.followUp}</p>` : ''}`;
  appendMessage('ai', html, true);
  if ((a.risk === 'high' || a.risk === 'medium') && state.doctors.length > 0) {
    setTimeout(() => {
      const recsHtml = `<p style="font-size:14px;margin-bottom:12px">Here are available specialists I recommend:</p>
        <div class="doctors-grid" style="grid-template-columns:1fr 1fr">${state.doctors.filter(d => d.available).slice(0, 4).map(d => `
          <div class="doctor-card" onclick="openDoctorModal(${d.id})">
            <div class="doctor-card-top"><div class="avatar ${d.color}">${d.emoji}</div><div><div class="doctor-name">${d.name}</div><div class="doctor-spec">${d.spec}</div></div></div>
            <div class="doctor-stars">${'★'.repeat(Math.floor(d.rating))} ${d.rating}</div>
            <button class="btn btn-primary btn-sm" style="width:100%;margin-top:8px" onclick="event.stopPropagation();quickBook('${d.name} — ${d.spec}')"><i class="fas fa-calendar-plus"></i> Book Now</button>
          </div>`).join('')}</div>`;
      appendMessage('ai', recsHtml, true);
    }, 800);
  }
}

async function clearChat() {
  await API.post('/chat/clear/', {});
  const msgs = document.getElementById('chat-messages');
  msgs.innerHTML = `<div class="chat-welcome" id="chat-welcome">
    <div class="chat-welcome-icon">🩺</div>
    <h3>Hello, I'm your Healix AI assistant</h3>
    <p>Describe your symptoms and I'll help analyze potential conditions, risk levels, and recommend specialists.</p>
    <div class="quick-chips">
      <div class="quick-chip" onclick="sendQuick('I have a severe headache and fever')">Headache & Fever</div>
      <div class="quick-chip" onclick="sendQuick('I have chest pain and shortness of breath')">Chest Pain</div>
      <div class="quick-chip" onclick="sendQuick('I have joint pain and fatigue')">Joint Pain</div>
      <div class="quick-chip" onclick="sendQuick('I have a persistent cough and sore throat')">Cough & Sore Throat</div>
      <div class="quick-chip" onclick="sendQuick('I feel dizzy and nauseous')">Dizziness</div>
      <div class="quick-chip" onclick="sendQuick('I have skin rash and itching')">Skin Rash</div>
    </div>
  </div>`;
  showToast('Chat cleared', 'info');
}

/* ========================
   VOICE INPUT
   ======================== */
function toggleVoice() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) { showToast('Voice input not supported in this browser', 'error'); return; }
  if (state.isListening) { state.recognition?.stop(); return; }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  state.recognition = new SR();
  state.recognition.continuous = false; state.recognition.interimResults = true; state.recognition.lang = 'en-US';
  state.recognition.onstart = () => { state.isListening = true; document.getElementById('voice-btn').classList.add('listening'); document.getElementById('mic-icon').className = 'fas fa-stop'; showToast('Listening… speak your symptoms', 'info'); };
  state.recognition.onresult = (e) => { document.getElementById('chat-input').value = Array.from(e.results).map(r => r[0].transcript).join(''); };
  state.recognition.onend = () => { state.isListening = false; document.getElementById('voice-btn').classList.remove('listening'); document.getElementById('mic-icon').className = 'fas fa-microphone'; };
  state.recognition.onerror = () => { state.isListening = false; document.getElementById('voice-btn').classList.remove('listening'); document.getElementById('mic-icon').className = 'fas fa-microphone'; showToast('Voice recognition error', 'error'); };
  state.recognition.start();
}

/* ========================
   APPOINTMENTS
   ======================== */
async function loadAppointments() {
  try {
    const res = await API.get('/appointments/list/');
    state.appointments = res.appointments || [];
    renderAppointments('all');
    const upcoming = state.appointments.filter(a => a.status === 'upcoming').length;
    const badge = document.getElementById('apt-badge');
    if (badge) badge.textContent = upcoming;
  } catch (e) { console.error('Failed to load appointments', e); }
}

function renderAppointments(filter) {
  const list = document.getElementById('appointment-list');
  if (!list) return;
  let apts = state.appointments;
  if (filter !== 'all') apts = apts.filter(a => a.status === filter);
  if (apts.length === 0) { list.innerHTML = '<div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No appointments found</h3><p>Book a new appointment to get started</p></div>'; return; }
  const statusColors = { upcoming: 'var(--accent-blue)', completed: 'var(--accent-teal)', cancelled: 'var(--risk-high)' };
  list.innerHTML = apts.map(a => `
    <div class="appointment-item">
      <div class="appointment-dot" style="background:${statusColors[a.status] || 'var(--accent-blue)'}"></div>
      <div class="appointment-info">
        <div class="appointment-name">${a.doctor}</div>
        <div class="appointment-meta">
          <span><i class="fas fa-stethoscope"></i> ${a.spec}</span>
          <span><i class="fas fa-calendar"></i> ${formatDate(a.date)}</span>
          <span><i class="fas fa-clock"></i> ${a.time}</span>
          <span><i class="fas fa-${a.type === 'Video' ? 'video' : 'hospital'}"></i> ${a.type}</span>
        </div>
        ${a.notes ? `<div style="font-size:12px;color:var(--text-muted);margin-top:3px">"${a.notes}"</div>` : ''}
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px">
        <span class="status-pill status-${a.status}">${a.status.charAt(0).toUpperCase() + a.status.slice(1)}</span>
        ${a.status === 'upcoming' ? `<div style="display:flex;gap:6px">
          <button class="btn btn-secondary btn-sm" onclick="goToVideoCall()"><i class="fas fa-video"></i></button>
          <button class="btn btn-danger btn-sm" onclick="cancelAppointment(${a.id})">Cancel</button>
        </div>` : ''}
      </div>
    </div>`).join('');
}

function filterApts(filter, el) {
  document.querySelectorAll('#panel-appointments .tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  renderAppointments(filter);
}

function openBookingModal(doctorName = '') {
  const modal = document.getElementById('booking-modal');
  modal.classList.remove('hidden');
  const d = new Date(); d.setDate(d.getDate() + 1);
  document.getElementById('book-date').value = d.toISOString().split('T')[0];
  if (doctorName) document.getElementById('book-doctor').value = doctorName;
}

function quickBook(name) { openBookingModal(name); }
function bookAppointmentFromChat() { showPanel('appointments'); openBookingModal(); }

async function confirmBooking() {
  const doctorFull = document.getElementById('book-doctor').value;
  const doctor = doctorFull.split('—')[0].trim();
  const spec = doctorFull.split('—')[1]?.trim() || 'Specialist';
  const date = document.getElementById('book-date').value;
  const time = document.getElementById('book-time').value;
  const type = document.getElementById('book-type').value.split(' ')[0];
  const notes = document.getElementById('book-notes').value;
  if (!date) { showToast('Please select a date', 'error'); return; }
  const res = await API.post('/appointments/book/', { doctor, spec, date, time, type, notes });
  if (res.ok) {
    await loadAppointments();
    closeModal('booking-modal');
    showPanel('appointments');
    showToast(`Appointment booked with ${doctor}! ✅`, 'success');
  } else showToast('Booking failed', 'error');
}

async function cancelAppointment(id) {
  const res = await API.post(`/appointments/cancel/${id}/`, {});
  if (res.ok) { await loadAppointments(); showToast('Appointment cancelled', 'info'); }
}

/* ========================
   DOCTORS
   ======================== */
async function loadDoctors() {
  try {
    const res = await API.get('/doctors/list/');
    state.doctors = res.doctors || [];
    renderDoctorsGrid(state.doctors);
  } catch (e) { console.error('Failed to load doctors', e); }
}

function renderDoctorsGrid(docs) {
  const grid = document.getElementById('doctors-grid');
  if (!grid) return;
  grid.innerHTML = docs.map(d => `
    <div class="doctor-card" onclick="openDoctorModal(${d.id})">
      <div class="doctor-card-top">
        <div class="avatar ${d.color}" style="width:44px;height:44px;font-size:20px">${d.emoji}</div>
        <div><div class="doctor-name">${d.name}</div><div class="doctor-spec">${d.spec}</div></div>
      </div>
      <div class="doctor-meta">
        <span><i class="fas fa-clock"></i>${d.exp}</span>
        <span><i class="fas fa-users"></i>${d.patients}</span>
        <span style="color:${d.available ? 'var(--accent-teal)' : 'var(--text-muted)'}">${d.available ? '● Available' : '○ Busy'}</span>
      </div>
      <div class="doctor-stars">${'★'.repeat(Math.floor(d.rating))}${'☆'.repeat(5 - Math.floor(d.rating))} ${d.rating} (${d.reviews})</div>
      <button class="btn btn-primary btn-sm" style="width:100%;margin-top:10px" onclick="event.stopPropagation();quickBook('${d.name} — ${d.spec}')">
        <i class="fas fa-calendar-plus"></i> Book Appointment
      </button>
    </div>`).join('');
}

function filterDoctors(q) {
  const filtered = state.doctors.filter(d => d.name.toLowerCase().includes(q.toLowerCase()) || d.spec.toLowerCase().includes(q.toLowerCase()));
  renderDoctorsGrid(filtered);
}

function openDoctorModal(id) {
  const d = state.doctors.find(x => x.id === id);
  if (!d) return;
  state.selectedDoctorForModal = d;
  document.getElementById('dm-title').textContent = d.name;
  const av = document.getElementById('dm-avatar');
  av.textContent = d.emoji; av.className = `avatar ${d.color}`;
  document.getElementById('dm-name').textContent = d.name;
  document.getElementById('dm-spec').textContent = d.spec;
  document.getElementById('dm-stars').innerHTML = `<span style="color:#fbbf24">${'★'.repeat(Math.floor(d.rating))}</span> ${d.rating} (${d.reviews} reviews)`;
  document.getElementById('dm-exp').textContent = d.exp;
  document.getElementById('dm-patients').textContent = d.patients;
  document.getElementById('dm-bio').textContent = d.bio;
  document.getElementById('doctor-modal').classList.remove('hidden');
}

function bookFromDoctorModal() {
  const d = state.selectedDoctorForModal;
  closeModal('doctor-modal');
  if (d) openBookingModal(`${d.name} — ${d.spec}`);
}

/* ========================
   DOCTOR DASHBOARD
   ======================== */
function greetDoctor() {
  const h = new Date().getHours();
  const g = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  document.getElementById('doctor-greeting').textContent = `${g}, ${state.currentUser}`;
}

async function initDoctorDashboard() {
  renderTodaySchedule();
  await loadPatientRequests();
  renderDoctorAppointments();
  renderPatientGrid();
}

function showDoctorPanel(name) {
  document.querySelectorAll('#doctor-dashboard .main-content > div[id^="dpanel-"]').forEach(p => p.classList.add('hidden'));
  document.getElementById('dpanel-' + name).classList.remove('hidden');
  document.querySelectorAll('#doctor-sidebar .nav-item').forEach(i => i.classList.remove('active'));
}

function renderTodaySchedule() {
  const el = document.getElementById('todays-schedule');
  if (!el) return;
  const items = [
    { time: '9:00 AM', name: 'Rahul Verma', type: 'Video', status: 'upcoming' },
    { time: '10:30 AM', name: 'Meera Singh', type: 'In-Person', status: 'upcoming' },
    { time: '12:00 PM', name: 'Arun Kumar', type: 'Video', status: 'completed' },
    { time: '2:30 PM', name: 'Sunita Rao', type: 'Video', status: 'upcoming' },
  ];
  el.innerHTML = items.map(i => `
    <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-subtle)">
      <div style="font-size:12px;color:var(--text-muted);min-width:60px">${i.time}</div>
      <div class="appointment-dot" style="background:${i.status === 'upcoming' ? 'var(--accent-blue)' : 'var(--accent-teal)'}"></div>
      <div style="flex:1"><div style="font-size:13px;font-weight:500">${i.name}</div><div style="font-size:11px;color:var(--text-secondary)">${i.type}</div></div>
      ${i.status === 'upcoming' ? `<button class="btn btn-secondary btn-sm" onclick="goToVideoCall()"><i class="fas fa-video"></i></button>` : '<span class="badge badge-low" style="font-size:10px">Done</span>'}
    </div>`).join('');
}

async function loadPatientRequests() {
  try {
    const res = await API.get('/doctors/requests/');
    state.patientRequests = res.requests || [];
    renderPendingRequestsMini();
    renderFullRequests();
    const pending = state.patientRequests.filter(r => !r.accepted).length;
    const badge = document.getElementById('req-badge');
    if (badge) badge.textContent = pending;
    const count = document.getElementById('pending-count');
    if (count) count.textContent = pending;
  } catch (e) { console.error('Failed to load requests', e); }
}

function renderPendingRequestsMini() {
  const el = document.getElementById('pending-requests-mini');
  if (!el) return;
  const pending = state.patientRequests.filter(r => !r.accepted).slice(0, 3);
  el.innerHTML = pending.map(r => `
    <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border-subtle)">
      <div class="avatar avatar-blue" style="width:32px;height:32px;font-size:13px">${r.name.charAt(0)}</div>
      <div style="flex:1"><div style="font-size:13px;font-weight:500">${r.name}</div><div style="font-size:11px;color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:160px">${r.symptom}</div></div>
      <span class="badge badge-${r.risk}">${r.risk}</span>
    </div>`).join('');
}

function renderFullRequests() {
  const el = document.getElementById('requests-list');
  if (!el) return;
  el.innerHTML = state.patientRequests.map(r => `
    <div class="patient-request">
      <div class="avatar avatar-blue" style="width:44px;height:44px;font-size:18px;flex-shrink:0">${r.name.charAt(0)}</div>
      <div class="patient-request-info">
        <div class="patient-request-name">${r.name} <span style="color:var(--text-muted);font-weight:400;font-size:13px">Age ${r.age}</span></div>
        <div class="patient-request-desc">${r.symptom}</div>
        <div class="patient-request-meta"><span><i class="fas fa-clock"></i> ${r.time}</span><span class="badge badge-${r.risk}" style="font-size:10px">${r.risk} risk</span></div>
      </div>
      <div class="patient-request-actions">
        ${r.accepted ? `<span class="badge badge-low">Accepted</span>` : `
          <button class="btn btn-success btn-sm" onclick="respondRequest(${r.id},'accept')"><i class="fas fa-check"></i> Accept</button>
          <button class="btn btn-danger btn-sm" onclick="respondRequest(${r.id},'decline')"><i class="fas fa-times"></i> Decline</button>`}
      </div>
    </div>`).join('');
}

async function respondRequest(id, action) {
  const res = await API.post(`/doctors/requests/${id}/respond/`, { action });
  if (res.ok) {
    await loadPatientRequests();
    showToast(action === 'accept' ? 'Appointment accepted ✅' : 'Request declined', action === 'accept' ? 'success' : 'info');
  }
}

function renderDoctorAppointments() {
  const el = document.getElementById('doctor-appointments-list');
  if (!el) return;
  const statusColors = { upcoming: 'var(--accent-blue)', completed: 'var(--accent-teal)', cancelled: 'var(--risk-high)' };
  el.innerHTML = state.appointments.map(a => `
    <div class="appointment-item">
      <div class="appointment-dot" style="background:${statusColors[a.status] || 'var(--accent-blue)'}"></div>
      <div class="appointment-info">
        <div class="appointment-name">Patient Appointment</div>
        <div class="appointment-meta"><span><i class="fas fa-calendar"></i> ${formatDate(a.date)}</span><span><i class="fas fa-clock"></i> ${a.time}</span><span><i class="fas fa-video"></i> ${a.type}</span></div>
        ${a.notes ? `<div style="font-size:12px;color:var(--text-muted);margin-top:3px">"${a.notes}"</div>` : ''}
      </div>
      <span class="status-pill status-${a.status}">${a.status.charAt(0).toUpperCase() + a.status.slice(1)}</span>
    </div>`).join('');
}

function renderPatientGrid() {
  const el = document.getElementById('patients-grid');
  if (!el) return;
  const patients = [
    { n: 'Rahul Verma', age: 34, condition: 'Cardiac Follow-up', visits: 3, c: 'avatar-blue' },
    { n: 'Meera Singh', age: 28, condition: 'Neurology', visits: 2, c: 'avatar-teal' },
    { n: 'Arun Kumar', age: 52, condition: 'Pulmonology', visits: 5, c: 'avatar-blue' },
    { n: 'Sunita Rao', age: 41, condition: 'General', visits: 1, c: 'avatar-teal' },
  ];
  el.innerHTML = patients.map(p => `
    <div class="doctor-card">
      <div class="doctor-card-top">
        <div class="avatar ${p.c}" style="width:44px;height:44px;font-size:16px;font-weight:700">${p.n.charAt(0)}</div>
        <div><div class="doctor-name">${p.n}</div><div class="doctor-spec">Age ${p.age} · ${p.condition}</div></div>
      </div>
      <div class="doctor-meta"><span><i class="fas fa-calendar-check"></i>${p.visits} visits</span></div>
      <button class="btn btn-secondary btn-sm" style="width:100%;margin-top:10px"><i class="fas fa-file-medical"></i> View Records</button>
    </div>`).join('');
}

/* ========================
   VIDEO CALL
   ======================== */
function goToVideoCall() {
  const prevPage = state.currentRole === 'doctor' ? 'doctor-dashboard' : 'patient-dashboard';
  state.prevPage = prevPage;
  document.getElementById(prevPage).classList.add('hidden');
  document.getElementById('video-page').classList.remove('hidden');
  startVideoCall();
}

function exitVideoCall() {
  stopVideoCall();
  document.getElementById('video-page').classList.add('hidden');
  const prev = state.prevPage || 'patient-dashboard';
  document.getElementById(prev).classList.remove('hidden');
}

async function startVideoCall() {
  try {
    state.videoStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    document.getElementById('local-video').srcObject = state.videoStream;
    startCallTimer();
    showToast('Camera connected — connecting to doctor...', 'success');
  } catch (e) { showToast('Camera access denied. Please enable camera permissions.', 'error'); }
}

function stopVideoCall() {
  if (state.videoStream) { state.videoStream.getTracks().forEach(t => t.stop()); state.videoStream = null; }
  clearInterval(state.callTimer); state.callSeconds = 0;
  document.getElementById('call-timer').textContent = '00:00';
}

function startCallTimer() {
  state.callSeconds = 0;
  state.callTimer = setInterval(() => {
    state.callSeconds++;
    const m = Math.floor(state.callSeconds / 60).toString().padStart(2, '0');
    const s = (state.callSeconds % 60).toString().padStart(2, '0');
    document.getElementById('call-timer').textContent = `${m}:${s}`;
  }, 1000);
}

function toggleVCMic() {
  state.micOn = !state.micOn;
  const btn = document.getElementById('vc-mic');
  if (state.videoStream) state.videoStream.getAudioTracks().forEach(t => t.enabled = state.micOn);
  btn.className = `vc-btn ${state.micOn ? 'vc-btn-normal' : 'vc-btn-muted'}`;
  btn.innerHTML = `<i class="fas fa-microphone${state.micOn ? '' : '-slash'}"></i>`;
}

function toggleVCCam() {
  state.camOn = !state.camOn;
  const btn = document.getElementById('vc-cam');
  if (state.videoStream) state.videoStream.getVideoTracks().forEach(t => t.enabled = state.camOn);
  btn.className = `vc-btn ${state.camOn ? 'vc-btn-normal' : 'vc-btn-muted'}`;
  btn.innerHTML = `<i class="fas fa-video${state.camOn ? '' : '-slash'}"></i>`;
}

async function toggleScreenShare() {
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
    document.getElementById('local-video').srcObject = stream;
    showToast('Screen sharing started', 'info');
    stream.getVideoTracks()[0].onended = () => {
      document.getElementById('local-video').srcObject = state.videoStream;
      showToast('Screen sharing stopped', 'info');
    };
  } catch (e) { showToast('Screen share cancelled', 'info'); }
}

/* ========================
   MODALS
   ======================== */
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
document.addEventListener('click', e => { if (e.target.classList.contains('modal-overlay')) e.target.classList.add('hidden'); });

/* ========================
   TOAST
   ======================== */
function showToast(msg, type = 'info') {
  const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle' };
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<i class="fas ${icons[type]}"></i>${msg}`;
  document.getElementById('toast-container').appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(60px)'; t.style.transition = 'all 0.3s'; setTimeout(() => t.remove(), 300); }, 3000);
}

/* ========================
   HELPERS
   ======================== */
function formatDate(d) { return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); }
function escapeHtml(t) { return t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>'); }

/* ========================
   INIT
   ======================== */
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => document.getElementById('login-email')?.focus(), 500);
  const today = new Date().toISOString().split('T')[0];
  const bookDate = document.getElementById('book-date');
  if (bookDate) bookDate.min = today;
  // Check if already logged in (Django session)
  fetch('/session/').then(r => r.json()).then(data => {
    if (data.authenticated) loginSuccess(data.name, data.role);
  }).catch(() => {});
});

/* ============================================================
   MEDICATIONS & PRESCRIPTIONS — app.js extension
   ============================================================ */

// ── State ──────────────────────────────────────────────────
state.medications = [];
state.prescriptions = [];
state.reminderTimers = {};
state.activeDoseLogMedId = null;

// ── Init ───────────────────────────────────────────────────
async function initMedications() {
  await loadMedications();
  await loadPrescriptions();
  scheduleAllReminders();
  updateReminderStatusBar();
}

// ── Load medications from backend ─────────────────────────
async function loadMedications() {
  try {
    const res = await API.get('/medications/list/');
    state.medications = res.medications || [];
    renderMedications('active');
  } catch (e) { console.error('Failed to load medications', e); }
}

async function loadPrescriptions() {
  try {
    const res = await API.get('/medications/prescriptions/');
    state.prescriptions = res.prescriptions || [];
    renderPrescriptions();
  } catch (e) { console.error('Failed to load prescriptions', e); }
}

// ── Render medications list ────────────────────────────────
function renderMedications(filter) {
  const list = document.getElementById('medications-list');
  if (!list) return;
  let meds = state.medications;
  if (filter === 'active')    meds = meds.filter(m => m.status === 'active');
  if (filter === 'completed') meds = meds.filter(m => m.status === 'completed');

  if (!meds.length) {
    const emptyMsg = filter === 'active'
      ? 'No active medications. Add one or wait for a doctor prescription.'
      : 'No medications found.';
    list.innerHTML = `<div class="empty-state"><i class="fas fa-pills"></i><h3>No medications</h3><p>${emptyMsg}</p></div>`;
    return;
  }

  const icons = ['💊', '💉', '🩺', '🔬'];
  const iconColors = ['med-icon-blue', 'med-icon-teal', 'med-icon-cyan', 'med-icon-amber'];

  list.innerHTML = meds.map((m, i) => {
    const icon = icons[i % icons.length];
    const iconColor = iconColors[i % iconColors.length];
    const daysInfo = m.duration_days
      ? (m.days_left !== null ? `${m.days_left} days left` : 'Completed')
      : 'Ongoing';
    const progress = m.duration_days && m.days_left !== null
      ? Math.round(((m.duration_days - m.days_left) / m.duration_days) * 100)
      : null;
    const reminderCount = m.reminder_times ? m.reminder_times.split(',').filter(Boolean).length : 0;
    const statusBadge = m.status === 'active'
      ? '<span class="badge badge-blue">Active</span>'
      : m.status === 'completed'
      ? '<span class="badge badge-low">Completed</span>'
      : '<span class="badge badge-medium">Paused</span>';

    return `
      <div class="med-card">
        <div class="med-icon ${iconColor}">${icon}</div>
        <div class="med-info">
          <div class="med-name">${m.name} <span style="font-weight:400;font-size:13px;color:var(--text-secondary)">${m.dosage}</span></div>
          <div class="med-meta">
            <span><i class="fas fa-clock"></i>${m.frequency}</span>
            <span><i class="fas fa-hourglass-half"></i>${daysInfo}</span>
            ${m.prescribed_by ? `<span><i class="fas fa-user-md"></i>${m.prescribed_by}</span>` : ''}
            ${reminderCount ? `<span><i class="fas fa-bell" style="color:var(--accent-blue)"></i>${reminderCount} reminder${reminderCount > 1 ? 's' : ''}</span>` : ''}
          </div>
          ${m.instructions ? `<div style="font-size:12px;color:var(--text-muted);font-style:italic">${m.instructions}</div>` : ''}
          ${progress !== null ? `<div class="med-progress-bar"><div class="med-progress-fill" style="width:${progress}%"></div></div>` : ''}
        </div>
        <div class="med-actions">
          ${statusBadge}
          ${m.status === 'active' ? `
            <button class="btn btn-primary btn-sm" onclick="openDoseLogModal(${m.id})">
              <i class="fas fa-check"></i> Log Dose
            </button>
            <button class="btn btn-secondary btn-sm" onclick="pauseMedication(${m.id})">
              <i class="fas fa-pause"></i>
            </button>
          ` : m.status === 'paused' ? `
            <button class="btn btn-secondary btn-sm" onclick="resumeMedication(${m.id})">
              <i class="fas fa-play"></i> Resume
            </button>
          ` : ''}
        </div>
      </div>`;
  }).join('');
}

function filterMeds(filter, el) {
  document.querySelectorAll('#panel-medications .tabs .tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  renderMedications(filter);
}

// ── Render prescriptions (patient) ────────────────────────
function renderPrescriptions() {
  const list = document.getElementById('prescriptions-list');
  if (!list) return;
  if (!state.prescriptions.length) {
    list.innerHTML = '<div class="empty-state"><i class="fas fa-file-prescription"></i><h3>No prescriptions yet</h3><p>Your doctor\'s prescriptions will appear here.</p></div>';
    return;
  }
  list.innerHTML = state.prescriptions.map(rx => `
    <div class="rx-card">
      <div class="rx-card-header">
        <div>
          <div class="rx-doctor-name"><i class="fas fa-user-md" style="color:var(--accent-blue);margin-right:6px"></i>${rx.doctor}</div>
          <div class="rx-date">${rx.created_at}</div>
        </div>
        <span class="badge badge-blue">Prescription</span>
      </div>
      ${rx.diagnosis ? `<div class="rx-diagnosis"><i class="fas fa-stethoscope" style="margin-right:4px"></i>${rx.diagnosis}</div>` : ''}
      ${rx.notes ? `<div class="rx-notes">"${rx.notes}"</div>` : ''}
      <div class="rx-med-list">
        ${rx.medications.map(m => `
          <div class="rx-med-item">
            <span style="font-size:16px">💊</span>
            <div class="rx-med-name">${m.name} <span style="font-size:12px;color:var(--text-muted)">${m.dosage}</span></div>
            <div class="rx-med-freq">${m.frequency}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `).join('');
}

// ── Add Medication Modal ───────────────────────────────────
function openAddMedModal() {
  document.getElementById('med-name').value = '';
  document.getElementById('med-dosage').value = '';
  document.getElementById('med-freq').value = 'once';
  document.getElementById('med-duration').value = '';
  document.getElementById('med-doctor').value = '';
  document.getElementById('med-instructions').value = '';
  document.getElementById('med-start').value = new Date().toISOString().split('T')[0];
  document.querySelectorAll('.reminder-chip').forEach(c => c.classList.remove('selected'));
  document.getElementById('add-med-modal').classList.remove('hidden');
}

function toggleReminderChip(el) {
  el.classList.toggle('selected');
}

async function confirmAddMedication() {
  const name = document.getElementById('med-name').value.trim();
  const dosage = document.getElementById('med-dosage').value.trim();
  if (!name || !dosage) { showToast('Please enter medication name and dosage', 'error'); return; }
  const reminderTimes = Array.from(document.querySelectorAll('.reminder-chip.selected'))
    .map(c => c.dataset.time).join(',');
  const res = await API.post('/medications/add/', {
    name, dosage,
    frequency: document.getElementById('med-freq').value,
    duration_days: parseInt(document.getElementById('med-duration').value) || null,
    start_date: document.getElementById('med-start').value,
    prescribed_by: document.getElementById('med-doctor').value.trim(),
    instructions: document.getElementById('med-instructions').value.trim(),
    reminder_times: reminderTimes,
  });
  if (res.ok) {
    await loadMedications();
    closeModal('add-med-modal');
    scheduleAllReminders();
    updateReminderStatusBar();
    showToast('Medication added ✅', 'success');
  } else showToast('Failed to add medication', 'error');
}

// ── Dose Log Modal ─────────────────────────────────────────
function openDoseLogModal(medId) {
  const med = state.medications.find(m => m.id === medId);
  if (!med) return;
  state.activeDoseLogMedId = medId;
  document.getElementById('dose-log-title').textContent = `Log Dose — ${med.name}`;
  document.getElementById('dose-log-desc').textContent =
    `${med.name} ${med.dosage} · ${med.frequency}${med.instructions ? ' · ' + med.instructions : ''}`;
  document.getElementById('dose-log-modal').classList.remove('hidden');
}

async function logDose(taken) {
  const medId = state.activeDoseLogMedId;
  if (!medId) return;
  const now = new Date();
  const time = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  const res = await API.post(`/medications/taken/${medId}/`, { time, skipped: !taken });
  closeModal('dose-log-modal');
  if (res.ok) {
    showToast(taken ? '✅ Dose logged as taken!' : 'Dose logged as skipped', taken ? 'success' : 'info');
  }
}

// ── Pause / Resume medication ──────────────────────────────
async function pauseMedication(medId) {
  const res = await API.post(`/medications/status/${medId}/`, { status: 'paused' });
  if (res.ok) { await loadMedications(); showToast('Medication paused', 'info'); }
}

async function resumeMedication(medId) {
  const res = await API.post(`/medications/status/${medId}/`, { status: 'active' });
  if (res.ok) { await loadMedications(); showToast('Medication resumed', 'success'); }
}

// ── REMINDER SYSTEM (Browser Notifications) ───────────────
function scheduleAllReminders() {
  // Clear all existing timers
  Object.values(state.reminderTimers).forEach(t => clearInterval(t));
  state.reminderTimers = {};

  const activeMeds = state.medications.filter(m => m.status === 'active' && m.reminder_times);
  activeMeds.forEach(med => {
    const times = med.reminder_times.split(',').filter(Boolean);
    times.forEach(t => {
      const key = `${med.id}-${t}`;
      // Check every minute if it's time
      state.reminderTimers[key] = setInterval(() => {
        const now = new Date();
        const nowStr = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
        if (nowStr === t) {
          triggerReminder(med, t);
        }
      }, 60000); // check every minute
    });
  });
}

function triggerReminder(med, time) {
  const title = `💊 Time for ${med.name}`;
  const body = `${med.dosage} · ${med.frequency}${med.instructions ? ' · ' + med.instructions : ''}`;

  // In-app toast always shown
  showToast(`⏰ Reminder: Take ${med.name} ${med.dosage} now!`, 'info');

  // Browser notification if permission granted
  if (Notification.permission === 'granted') {
    const notif = new Notification(title, {
      body,
      icon: '/static/favicon.ico',
      badge: '/static/favicon.ico',
      tag: `healix-med-${med.id}-${time}`,
      requireInteraction: true,
    });
    notif.onclick = () => {
      window.focus();
      openDoseLogModal(med.id);
      notif.close();
    };
  }
}

async function requestNotificationPermission() {
  if (!('Notification' in window)) {
    showToast('Your browser does not support notifications', 'error');
    return;
  }
  const permission = await Notification.requestPermission();
  if (permission === 'granted') {
    showToast('✅ Notifications enabled! You\'ll be reminded to take your medications.', 'success');
    updateReminderStatusBar();
    closeModal('reminder-settings-modal');
  } else {
    showToast('Notification permission denied. You can change this in browser settings.', 'error');
  }
}

function updateReminderStatusBar() {
  const bar = document.getElementById('reminder-status-bar');
  const txt = document.getElementById('reminder-status-text');
  if (!bar || !txt) return;
  const activeMeds = state.medications.filter(m => m.status === 'active' && m.reminder_times);
  if (!activeMeds.length) { bar.style.display = 'none'; return; }
  bar.style.display = 'flex';
  const totalReminders = activeMeds.reduce((acc, m) => acc + m.reminder_times.split(',').filter(Boolean).length, 0);
  const permStatus = Notification.permission === 'granted' ? '🔔 active' : '⚠️ not enabled';
  txt.textContent = `${activeMeds.length} medication${activeMeds.length > 1 ? 's' : ''} · ${totalReminders} reminder${totalReminders > 1 ? 's' : ''} per day · Notifications ${permStatus}`;
}

function openReminderSettingsModal() {
  const list = document.getElementById('reminder-meds-list');
  const activeMeds = state.medications.filter(m => m.status === 'active');
  if (!activeMeds.length) {
    list.innerHTML = '<p style="color:var(--text-secondary);font-size:14px">No active medications.</p>';
  } else {
    list.innerHTML = activeMeds.map(m => {
      const times = m.reminder_times ? m.reminder_times.split(',').filter(Boolean) : [];
      return `
        <div style="padding:12px 0;border-bottom:1px solid var(--border-subtle)">
          <div style="font-size:14px;font-weight:600;margin-bottom:4px">💊 ${m.name} ${m.dosage}</div>
          <div style="font-size:12px;color:var(--text-secondary)">${m.frequency}</div>
          <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
            ${times.length ? times.map(t => `<span class="badge badge-blue"><i class="fas fa-bell"></i> ${formatTime12h(t)}</span>`).join('') : '<span style="font-size:12px;color:var(--text-muted)">No reminders set</span>'}
          </div>
        </div>`;
    }).join('');
  }
  document.getElementById('reminder-settings-modal').classList.remove('hidden');
}

function formatTime12h(t) {
  const [h, m] = t.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${String(m).padStart(2,'0')} ${ampm}`;
}

// ── SEND PRESCRIPTION (Doctor) ────────────────────────────
let rxMedRowCount = 0;

function openSendPrescriptionModal() {
  document.getElementById('rx-patient-email').value = '';
  document.getElementById('rx-diagnosis').value = '';
  document.getElementById('rx-notes').value = '';
  document.getElementById('rx-med-rows').innerHTML = '';
  rxMedRowCount = 0;
  addRxMedRow(); // start with one row
  document.getElementById('send-rx-modal').classList.remove('hidden');
}

function addRxMedRow() {
  rxMedRowCount++;
  const id = rxMedRowCount;
  const row = document.createElement('div');
  row.className = 'rx-med-row';
  row.id = `rx-row-${id}`;
  row.innerHTML = `
    <button class="remove-btn" onclick="removeRxMedRow(${id})" title="Remove"><i class="fas fa-times"></i></button>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:8px">
      <div class="form-group" style="margin-bottom:0"><label class="form-label">Medicine</label><input type="text" class="form-control" id="rx-med-name-${id}" placeholder="e.g. Amoxicillin"></div>
      <div class="form-group" style="margin-bottom:0"><label class="form-label">Dosage</label><input type="text" class="form-control" id="rx-med-dosage-${id}" placeholder="e.g. 500mg"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-bottom:8px">
      <div class="form-group" style="margin-bottom:0"><label class="form-label">Frequency</label>
        <select class="form-select" id="rx-med-freq-${id}">
          <option value="once">Once daily</option>
          <option value="twice">Twice daily</option>
          <option value="thrice">Three times daily</option>
          <option value="every6h">Every 6 hours</option>
          <option value="every8h">Every 8 hours</option>
          <option value="weekly">Weekly</option>
          <option value="asneeded">As needed</option>
        </select>
      </div>
      <div class="form-group" style="margin-bottom:0"><label class="form-label">Days</label><input type="number" class="form-control" id="rx-med-days-${id}" placeholder="(blank=ongoing)"></div>
      <div class="form-group" style="margin-bottom:0"><label class="form-label">Reminders</label>
        <select class="form-select" id="rx-med-reminder-${id}">
          <option value="">None</option>
          <option value="08:00">8 AM</option>
          <option value="08:00,20:00">8 AM & 8 PM</option>
          <option value="08:00,14:00,20:00">8 AM, 2 PM & 8 PM</option>
          <option value="06:00,12:00,18:00,22:00">6-hourly</option>
        </select>
      </div>
    </div>
    <div class="form-group" style="margin-bottom:0"><label class="form-label">Instructions</label><input type="text" class="form-control" id="rx-med-inst-${id}" placeholder="e.g. Take after food"></div>
  `;
  document.getElementById('rx-med-rows').appendChild(row);
}

function removeRxMedRow(id) {
  const row = document.getElementById(`rx-row-${id}`);
  if (row) row.remove();
}

async function confirmSendPrescription() {
  const patientEmail = document.getElementById('rx-patient-email').value.trim();
  const diagnosis = document.getElementById('rx-diagnosis').value.trim();
  const notes = document.getElementById('rx-notes').value.trim();
  if (!patientEmail) { showToast('Please enter patient email', 'error'); return; }

  const medRows = document.querySelectorAll('.rx-med-row');
  const medications = [];
  let valid = true;
  medRows.forEach(row => {
    const idMatch = row.id.match(/rx-row-(\d+)/);
    if (!idMatch) return;
    const i = idMatch[1];
    const name = document.getElementById(`rx-med-name-${i}`)?.value.trim();
    const dosage = document.getElementById(`rx-med-dosage-${i}`)?.value.trim();
    if (!name || !dosage) { valid = false; return; }
    medications.push({
      name, dosage,
      frequency: document.getElementById(`rx-med-freq-${i}`)?.value || 'once',
      duration_days: parseInt(document.getElementById(`rx-med-days-${i}`)?.value) || null,
      instructions: document.getElementById(`rx-med-inst-${i}`)?.value.trim() || '',
      reminder_times: document.getElementById(`rx-med-reminder-${i}`)?.value || '',
    });
  });

  if (!valid || !medications.length) { showToast('Please fill in all medicine names and dosages', 'error'); return; }

  const res = await API.post('/medications/prescriptions/send/', { patient_email: patientEmail, diagnosis, notes, medications });
  if (res.ok) {
    closeModal('send-rx-modal');
    showToast(`✅ Prescription sent to ${res.patient}!`, 'success');
    await loadDoctorPrescriptions();
  } else {
    showToast(res.error || 'Failed to send prescription', 'error');
  }
}

// ── Doctor prescription list ───────────────────────────────
async function loadDoctorPrescriptions() {
  try {
    const res = await API.get('/medications/prescriptions/sent/');
    renderDoctorPrescriptions(res.prescriptions || []);
  } catch (e) { console.error('Failed to load doctor prescriptions', e); }
}

function renderDoctorPrescriptions(rxs) {
  const list = document.getElementById('doctor-rx-list');
  if (!list) return;
  if (!rxs.length) {
    list.innerHTML = '<div class="empty-state"><i class="fas fa-file-prescription"></i><h3>No prescriptions sent yet</h3><p>Send your first prescription using the button above.</p></div>';
    return;
  }
  list.innerHTML = rxs.map(rx => `
    <div class="doc-rx-card">
      <div class="doc-rx-card-header">
        <div>
          <div style="font-size:15px;font-weight:600"><i class="fas fa-user" style="color:var(--accent-teal);margin-right:6px"></i>${rx.patient}</div>
          <div style="font-size:12px;color:var(--text-muted)">${rx.patient_email} · ${rx.created_at}</div>
        </div>
        <span class="badge badge-blue">${rx.medications.length} medicine${rx.medications.length !== 1 ? 's' : ''}</span>
      </div>
      ${rx.diagnosis ? `<div style="font-size:13px;color:var(--accent-cyan);margin-bottom:10px"><i class="fas fa-stethoscope" style="margin-right:4px"></i>${rx.diagnosis}</div>` : ''}
      <div class="rx-med-list">
        ${rx.medications.map(m => `
          <div class="rx-med-item">
            <span style="font-size:14px">💊</span>
            <div class="rx-med-name">${m.name} <span style="color:var(--text-muted)">${m.dosage}</span></div>
            <div class="rx-med-freq">${m.frequency}</div>
          </div>
        `).join('')}
      </div>
      ${rx.notes ? `<div style="font-size:12px;color:var(--text-secondary);margin-top:10px;font-style:italic">"${rx.notes}"</div>` : ''}
    </div>
  `).join('');
}

function switchRxTab(tab, el) {
  document.querySelectorAll('#dpanel-prescriptions .tabs .tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
}

// ── Override initPatientDashboard to include medications ───
const _origInitPatientDashboard = initPatientDashboard;
initPatientDashboard = async function() {
  await _origInitPatientDashboard();
  await initMedications();
};

// ── Override initDoctorDashboard to include prescriptions ──
const _origInitDoctorDashboard = initDoctorDashboard;
initDoctorDashboard = async function() {
  await _origInitDoctorDashboard();
  // preload doctor rx list when doctor panel is opened
};

// ── Override showDoctorPanel to load prescriptions lazily ─
const _origShowDoctorPanel = showDoctorPanel;
showDoctorPanel = function(name) {
  _origShowDoctorPanel(name);
  if (name === 'prescriptions') {
    loadDoctorPrescriptions();
  }
};
