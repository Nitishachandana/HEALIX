import json
from django.shortcuts import redirect
from django.contrib.auth import authenticate, login, logout
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from .models import CustomUser


@csrf_exempt
@require_POST
def login_view(request):
    data = json.loads(request.body)
    email = data.get('email', '').strip()
    password = data.get('password', '').strip()
    role = data.get('role', 'patient')

    # Demo login shortcut
    if data.get('demo'):
        username = f'demo_{role}'
        user, created = CustomUser.objects.get_or_create(
            username=username,
            defaults={
                'email': f'{username}@healix.ai',
                'role': role,
                'first_name': role.capitalize(),
                'last_name': 'Demo',
            }
        )
        if created:
            user.set_password('demo1234')
            user.save()
        login(request, user)
        return JsonResponse({'ok': True, 'role': role, 'name': user.display_name})

    try:
        user_obj = CustomUser.objects.get(email=email)
    except CustomUser.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'No account with that email.'}, status=400)

    user = authenticate(request, username=user_obj.username, password=password)
    if user:
        login(request, user)
        return JsonResponse({'ok': True, 'role': user.role, 'name': user.display_name})
    return JsonResponse({'ok': False, 'error': 'Invalid password.'}, status=400)


@csrf_exempt
@require_POST
def signup_view(request):
    data = json.loads(request.body)
    name = data.get('name', '').strip()
    email = data.get('email', '').strip()
    password = data.get('password', '').strip()
    role = data.get('role', 'patient')

    if not all([name, email, password]):
        return JsonResponse({'ok': False, 'error': 'All fields are required.'}, status=400)
    if CustomUser.objects.filter(email=email).exists():
        return JsonResponse({'ok': False, 'error': 'Email already registered.'}, status=400)
    if len(password) < 8:
        return JsonResponse({'ok': False, 'error': 'Password must be at least 8 characters.'}, status=400)

    parts = name.split(' ', 1)
    first = parts[0]
    last = parts[1] if len(parts) > 1 else ''
    username = email.split('@')[0]
    # Ensure unique username
    base = username
    i = 1
    while CustomUser.objects.filter(username=username).exists():
        username = f'{base}{i}'; i += 1

    user = CustomUser.objects.create_user(
        username=username, email=email, password=password,
        first_name=first, last_name=last, role=role
    )
    login(request, user)
    return JsonResponse({'ok': True, 'role': role, 'name': user.display_name})


def logout_view(request):
    logout(request)
    return JsonResponse({'ok': True})
