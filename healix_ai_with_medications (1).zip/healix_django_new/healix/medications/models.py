from django.db import models
from django.conf import settings


class Prescription(models.Model):
    """Doctor sends a prescription to a patient."""
    doctor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='prescriptions_sent'
    )
    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='prescriptions_received'
    )
    diagnosis = models.CharField(max_length=255, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Rx from {self.doctor} to {self.patient} ({self.created_at.date()})"


class Medication(models.Model):
    FREQUENCY_CHOICES = [
        ('once', 'Once daily'),
        ('twice', 'Twice daily'),
        ('thrice', 'Three times daily'),
        ('every4h', 'Every 4 hours'),
        ('every6h', 'Every 6 hours'),
        ('every8h', 'Every 8 hours'),
        ('weekly', 'Weekly'),
        ('asneeded', 'As needed'),
    ]
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('paused', 'Paused'),
    ]

    prescription = models.ForeignKey(
        Prescription, on_delete=models.CASCADE,
        related_name='medications', null=True, blank=True
    )
    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='medications'
    )
    name = models.CharField(max_length=200)
    dosage = models.CharField(max_length=100)           # e.g. "500mg"
    frequency = models.CharField(max_length=20, choices=FREQUENCY_CHOICES, default='once')
    duration_days = models.IntegerField(null=True, blank=True)  # None = ongoing
    start_date = models.DateField()
    instructions = models.TextField(blank=True)         # e.g. "take after food"
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    prescribed_by = models.CharField(max_length=120, blank=True)  # Doctor display name
    reminder_times = models.CharField(max_length=200, blank=True)  # "08:00,14:00,20:00" CSV
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} {self.dosage} — {self.patient}"

    @property
    def days_left(self):
        if not self.duration_days:
            return None
        from django.utils import timezone
        elapsed = (timezone.now().date() - self.start_date).days
        return max(0, self.duration_days - elapsed)


class MedicationLog(models.Model):
    """Track each time a patient marks a dose as taken."""
    medication = models.ForeignKey(Medication, on_delete=models.CASCADE, related_name='logs')
    taken_at = models.DateTimeField(auto_now_add=True)
    scheduled_time = models.CharField(max_length=10, blank=True)  # "08:00"
    skipped = models.BooleanField(default=False)

    class Meta:
        ordering = ['-taken_at']
