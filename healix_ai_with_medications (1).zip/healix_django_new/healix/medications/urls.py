from django.urls import path
from . import views

urlpatterns = [
    # Patient
    path('list/', views.list_medications, name='list_medications'),
    path('add/', views.add_medication, name='add_medication'),
    path('taken/<int:med_id>/', views.mark_taken, name='mark_taken'),
    path('status/<int:med_id>/', views.update_medication_status, name='update_medication_status'),
    path('prescriptions/', views.list_prescriptions, name='list_prescriptions'),
    # Doctor
    path('prescriptions/send/', views.send_prescription, name='send_prescription'),
    path('prescriptions/sent/', views.doctor_prescriptions_sent, name='doctor_prescriptions_sent'),
]
