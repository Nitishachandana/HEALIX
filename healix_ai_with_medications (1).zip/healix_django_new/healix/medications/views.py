import json
from datetime import date
from django.http import JsonResponse
from django.views.decorators.http import require_POST, require_GET
from django.contrib.auth.decorators import login_required
from .models import Prescription, Medication, MedicationLog
from users.models import CustomUser


# ───────────── PATIENT views ─────────────

@login_required
@require_GET
def list_medications(request):
    """Return all medications for the logged-in patient."""
    meds = Medication.objects.filter(patient=request.user)
    data = []
    for m in meds:
        data.append({
            'id': m.id,
            'name': m.name,
            'dosage': m.dosage,
            'frequency': m.get_frequency_display(),
            'frequency_key': m.frequency,
            'duration_days': m.duration_days,
            'days_left': m.days_left,
            'start_date': str(m.start_date),
            'instructions': m.instructions,
            'status': m.status,
            'prescribed_by': m.prescribed_by,
            'reminder_times': m.reminder_times,
            'prescription_id': m.prescription_id,
        })
    return JsonResponse({'ok': True, 'medications': data})


@login_required
@require_POST
def add_medication(request):
    """Patient manually adds a medication."""
    body = json.loads(request.body)
    m = Medication.objects.create(
        patient=request.user,
        name=body.get('name', ''),
        dosage=body.get('dosage', ''),
        frequency=body.get('frequency', 'once'),
        duration_days=body.get('duration_days') or None,
        start_date=body.get('start_date') or date.today(),
        instructions=body.get('instructions', ''),
        status='active',
        prescribed_by=body.get('prescribed_by', ''),
        reminder_times=body.get('reminder_times', ''),
    )
    return JsonResponse({'ok': True, 'id': m.id})


@login_required
@require_POST
def mark_taken(request, med_id):
    """Log a dose as taken."""
    body = json.loads(request.body)
    try:
        med = Medication.objects.get(id=med_id, patient=request.user)
    except Medication.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
    MedicationLog.objects.create(
        medication=med,
        scheduled_time=body.get('time', ''),
        skipped=body.get('skipped', False),
    )
    return JsonResponse({'ok': True})


@login_required
@require_POST
def update_medication_status(request, med_id):
    body = json.loads(request.body)
    try:
        med = Medication.objects.get(id=med_id, patient=request.user)
    except Medication.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Not found'}, status=404)
    med.status = body.get('status', med.status)
    med.save()
    return JsonResponse({'ok': True})


@login_required
@require_GET
def list_prescriptions(request):
    """Return prescriptions received by the logged-in patient."""
    rxs = Prescription.objects.filter(patient=request.user).prefetch_related('medications')
    data = []
    for rx in rxs:
        data.append({
            'id': rx.id,
            'doctor': rx.doctor.display_name,
            'diagnosis': rx.diagnosis,
            'notes': rx.notes,
            'created_at': rx.created_at.strftime('%b %d, %Y'),
            'medications': [{'name': m.name, 'dosage': m.dosage, 'frequency': m.get_frequency_display()} for m in rx.medications.all()],
        })
    return JsonResponse({'ok': True, 'prescriptions': data})


# ───────────── DOCTOR views ─────────────

@login_required
@require_POST
def send_prescription(request):
    """Doctor sends a prescription to a patient (by username or email)."""
    if request.user.role != 'doctor':
        return JsonResponse({'ok': False, 'error': 'Only doctors can send prescriptions'}, status=403)

    body = json.loads(request.body)
    patient_email = body.get('patient_email', '').strip()
    try:
        patient = CustomUser.objects.get(email__iexact=patient_email)
    except CustomUser.DoesNotExist:
        return JsonResponse({'ok': False, 'error': 'Patient not found with that email'})

    rx = Prescription.objects.create(
        doctor=request.user,
        patient=patient,
        diagnosis=body.get('diagnosis', ''),
        notes=body.get('notes', ''),
    )

    meds_data = body.get('medications', [])
    for med in meds_data:
        Medication.objects.create(
            prescription=rx,
            patient=patient,
            name=med.get('name', ''),
            dosage=med.get('dosage', ''),
            frequency=med.get('frequency', 'once'),
            duration_days=med.get('duration_days') or None,
            start_date=date.today(),
            instructions=med.get('instructions', ''),
            status='active',
            prescribed_by=request.user.display_name,
            reminder_times=med.get('reminder_times', ''),
        )

    return JsonResponse({'ok': True, 'prescription_id': rx.id, 'patient': patient.display_name})


@login_required
@require_GET
def doctor_prescriptions_sent(request):
    """List all prescriptions this doctor has sent."""
    if request.user.role != 'doctor':
        return JsonResponse({'ok': False, 'error': 'Forbidden'}, status=403)
    rxs = Prescription.objects.filter(doctor=request.user).prefetch_related('medications')
    data = []
    for rx in rxs:
        data.append({
            'id': rx.id,
            'patient': rx.patient.display_name,
            'patient_email': rx.patient.email,
            'diagnosis': rx.diagnosis,
            'notes': rx.notes,
            'created_at': rx.created_at.strftime('%b %d, %Y'),
            'medications': [{'name': m.name, 'dosage': m.dosage, 'frequency': m.get_frequency_display()} for m in rx.medications.all()],
        })
    return JsonResponse({'ok': True, 'prescriptions': data})
