from django.contrib import admin
from .models import Prescription, Medication, MedicationLog

@admin.register(Prescription)
class PrescriptionAdmin(admin.ModelAdmin):
    list_display = ['doctor', 'patient', 'diagnosis', 'created_at']

@admin.register(Medication)
class MedicationAdmin(admin.ModelAdmin):
    list_display = ['name', 'dosage', 'patient', 'prescribed_by', 'status', 'start_date']

@admin.register(MedicationLog)
class MedicationLogAdmin(admin.ModelAdmin):
    list_display = ['medication', 'taken_at', 'skipped']
